/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advenced_programming_pro;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.Transaction;
public class Sign_upController implements Initializable {
    
    
    
 private static final String regex = "^(.+)@(.+)$";
 
 public static int company_id=0;
 
 
        @FXML
    private MediaView mediaView;
    
    @FXML
    private JFXTextField nameTextFeild;

    @FXML
    private JFXTextField EmailTextFeild;

    @FXML
    private JFXPasswordField passwordTextFeild;

    @FXML
    private JFXButton buttton;

    @FXML
    private Label labemsg;

        
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    
    @FXML
    void GOHOME(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("home.fxml"));
stage=(Stage)((Node)event.getSource()).getScene().getWindow();
scene=new Scene(root);
stage.setScene(scene);
stage.show();

    }

    @FXML
    void GOLOGIN(ActionEvent event) throws IOException {
Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
stage=(Stage)((Node)event.getSource()).getScene().getWindow();
scene=new Scene(root);
stage.setScene(scene);
stage.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         Media media = new Media("file:///C:/Users/xxsha/Desktop/vedio.mp4");
        MediaPlayer player = new MediaPlayer(media);
        mediaView.setMediaPlayer(player);
        player.setCycleCount(MediaPlayer.INDEFINITE);
        player.setVolume(0);
        player.play();
        
              buttton.setOnAction(e->{ 
       Pattern pattern = Pattern.compile(regex);
        
        Matcher matcher = pattern.matcher(EmailTextFeild.getText());
        boolean validate =matcher.matches();
        
       if(nameTextFeild.getText().isEmpty()||EmailTextFeild.getText().isEmpty()||passwordTextFeild.getText().isEmpty()) //TextField FName 
             labemsg.setText("Please Complete the fields");
        
       else{
     
        if(!validate) 
             labemsg.setText("invalid Email");
        else {
            
            if(passwordTextFeild.getText().length() <8)
                labemsg.setText("The length must be higher than 8 digits");
            else{
                   
            labemsg.setText("");
            
                 Parent root;
            try {
            root = FXMLLoader.load(getClass().getResource("home.fxml"));
                stage=(Stage)((Node)e.getSource()).getScene().getWindow();
                scene=new Scene(root);
                stage.setScene(scene);
                stage.show();
                
                
         commpany_pojo cpmpany=new commpany_pojo();
         cpmpany.setCompany_name(nameTextFeild.getText());
         cpmpany.setCompany_email(EmailTextFeild.getText());
         cpmpany.setCompany_paasword(passwordTextFeild.getText());
        Session session = HibernateUtil.getSessionFactory().openSession();
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(cpmpany);
        tx.commit();
        System.out.println("id "+cpmpany.getCompany_id());
        company_id=cpmpany.getCompany_id();
        session.close();

     
     
     
            } catch (IOException ex) {
                Logger.getLogger(Sign_upController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        }
               
       }

          
           });
    }    
    
}
