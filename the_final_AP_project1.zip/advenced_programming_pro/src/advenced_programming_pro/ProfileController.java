/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advenced_programming_pro;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import static javax.management.Query.value;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author ab00e
 */
public class ProfileController implements Initializable {
    private Stage stage;
    private Scene scene;
    private Parent root;
  

 

    @FXML
    public static Label usernameLabel;

    @FXML
    public static Label emailLabel;

    @FXML
    public static Label passwordLabel;
    
     
     @FXML
    private Button backHomeButton;
     @FXML
    void gohome(ActionEvent event) throws IOException {
                Parent root = FXMLLoader.load(getClass().getResource("home.fxml"));
stage=(Stage)((Node)event.getSource()).getScene().getWindow();
scene=new Scene(root);
stage.setScene(scene);
stage.show();
    }
    
    

      @FXML
 void showProfile(ActionEvent event) throws IOException {
    
     
     commpany_pojo p1 = new commpany_pojo();
     
     
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<commpany_pojo> sList = null;
        String queryStr = "from commpany_pojo";
        Query query = session.createQuery(queryStr);
        sList = query.list();
        session.close();
        System.out.println("Profile list size: "+sList.size());
        for(commpany_pojo s: sList)
        {
            usernameLabel.setText(s.getCompany_name());
            emailLabel.setText(s.getCompany_email());
            passwordLabel.setText(s.getCompany_paasword());
            
        }
     
     
     
     
     /*String fn = "Abeer Adam";
       String n = "Abeer";
       String e = "e@gmail,com";
       String p = "11111111";
      inputfNameLable.setText(fn.toUpperCase());
      inputNameLable.setText(n.toUpperCase());
      emailInputLable.setText(e);
      passInputLable.setText(p);
      
     Profile_pojo p1 = new Profile_pojo();
     p1.setFName(fn);
     p1.setName(n);
     p1.setEmail(e);
     p1.setPass(p);
     
    Session session = HibernateUtil.getSessionFactory().openSession();
      Transaction  tx = session.beginTransaction();
        String idFn = (String) session.save(p1);
        tx.commit();
        session.close();
        System.out.println("inserted Student: "+p1);
     
      */
   }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
       
    }
        
        
        
        
        
    }

  
 
    

