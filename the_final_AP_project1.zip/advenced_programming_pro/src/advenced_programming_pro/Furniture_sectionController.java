/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advenced_programming_pro;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
public class Furniture_sectionController implements Initializable {

  
    
        @FXML
    private JFXButton cartbutton;
    
    @FXML
    private VBox chosenbag;

    @FXML
    private VBox addressbox;

    @FXML
    private Label addressname;

    @FXML
    private Label addresscity;

    @FXML
    private Label addresscode;

    @FXML
    private ImageView bagimage;
    
        @FXML
    private ScrollPane scroll;

    @FXML
    private GridPane grid;
   
     @FXML
    private Button addButton;
     

     
    
    private Stage stage;
    private Scene scene;
    private Parent root;
        @FXML
    void Home(ActionEvent event) throws IOException {
        
Parent root = FXMLLoader.load(getClass().getResource("home.fxml"));
stage=(Stage)((Node)event.getSource()).getScene().getWindow();
scene=new Scene(root);
stage.setScene(scene);
stage.show();
    }


    
      private bag furniture;
      
    
    private List<bag> furnitures= new ArrayList<>();

    

    private Image image;
    private myListener myListener;
    
    
    
    
    private List<bag> getData(){   // نسوي ارري ونخزن داخلها اوبجكتس
    
        List<bag> furnitures = new ArrayList<>();
        bag furniture; //just intilise object 
        
        
       
        furniture=new bag();
        furniture.setMaddressname("Mrs.Noura");
        furniture.setMaddresscity("jeddah 12987-7318");
        furniture.setMaddresscode("0566473865");
        furniture.setImgSrc("F1.jpeg");
        furniture.setColor("F7C995");
        furnitures.add(furniture);  // add to up private List<bag> bags= new ArrayList<>();
        
        furniture=new bag();
        furniture.setMaddressname("Mrs.Reem");
        furniture.setMaddresscity("RIYADH 11564");
        furniture.setMaddresscode("0566473652");
        furniture.setImgSrc("F2.jpeg");
        furniture.setColor("D3967A");
        furnitures.add(furniture);
        
        furniture=new bag();
        furniture.setMaddressname("Mrs.Sadeem");
        furniture.setMaddresscity("NAJRAN 122-64");
        furniture.setMaddresscode("0566473542");
        furniture.setImgSrc("F3.jpeg");
        furniture.setColor("EAEAEA");
        furnitures.add(furniture);
        return furnitures;
        

    }
        private void setChosenBag(bag furniture) {   //استخدمناه تحت  , تعبي اللي فالكارد
       
        addressname.setText(furniture.getMaddressname());
        addresscity.setText(furniture.getMaddresscity());
        addresscode.setText(furniture.getMaddresscode());
        image = new Image(getClass().getResourceAsStream(furniture.getImgSrc())); 
        bagimage.setImage(image);
        chosenbag.setStyle("-fx-background-color: #"+furniture.getColor()+";"+"-fx-background-radius: 30;"); //  يجيب اللون حق الكارد المختاره

    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
         furnitures.addAll(getData());   //خزنا دداخل الاريي لست اري لست 
       
         
         
         if(furnitures.size() > 0){
             setChosenBag(furnitures.get(0));  // ??????????????????????????????????   هنا بس حطيت اول باق فقط 
             
             myListener=new myListener() {
                 @Override  // from the interface
                 public void onClickListener(bag furniture) {                       ////؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟ ارجع اشوف الفيديو + افهم اللسنير 
                                                                              ///اذا انا سويت اكشن هنا فعل هذي الجزئيه 
                    setChosenBag(furniture);  // نمرر هذي الاوبجكت في المربع اليسار
                 }

                 
             };
                 
                 
             
         }
         int column=0;
         int row=1;
         try {
            for(int i = 0 ; i<furnitures.size(); i++){  // هنا نضيف اف السايز لايساوي الصفر 
         
             FXMLLoader fxmlloader= new FXMLLoader(); // 
             fxmlloader.setLocation(getClass().getResource("item.fxml"));            //اجيب السين اللي في  fxml item   /*فيه شرح فاليوتيوب*/
             AnchorPane anchorpane= fxmlloader.load();              //سوينا انككور وحطينا داخله السين اللي في الايتم 
             
           //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
           
            ItemController itemcontroller = fxmlloader.getController();
            itemcontroller.setData(furnitures.get(i),myListener); // ميثور في الايتم كنترولير 2 
            
            if(column == 3){     //اذا العامود صار ثلاثه ارجع من العامود 0 وزود الصف واحد 
                column=0;
                row++;
            }
            
           
             //set grid width
            grid.add(anchorpane,column++,row); //(child,colomun,row) // ابحث قوقل , هنا ضاف فالقرد الايتم 
            grid.setMinWidth(Region.USE_COMPUTED_SIZE);
            grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
            grid.setMaxWidth(Region.USE_PREF_SIZE);
            GridPane.setMargin(anchorpane, new Insets(10, 10, 10, 10));
            
            //set grid hight
            
            grid.setMinHeight(Region.USE_COMPUTED_SIZE);
            grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
            grid.setMaxHeight(Region.USE_PREF_SIZE);
            
            
         }
            } catch (IOException ex) {
                 Logger.getLogger(Furniture_sectionController.class.getName()).log(Level.SEVERE, null, ex);
                 
                 
             }
    }    
    
}
