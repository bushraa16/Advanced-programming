/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advenced_programming_pro;

import static advenced_programming_pro.Sign_upController.company_id;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import static java.sql.Statement.RETURN_GENERATED_KEYS;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.Transaction;
public class Add_donationController implements Initializable {

   

        ObservableList<String>  obName;
        ObservableList<String>  obaddress;
        ObservableList<String>  obmobile;
        ObservableList<String>  obDate;
    
        
    @FXML
    private JFXTextField mobileTextFeild;   
          

    @FXML
    private Label namelLabel;

    @FXML
    private JFXTextField nameTextFeild;

    @FXML
    private Label quantityLabel;

    @FXML
    private JFXComboBox<String> compobox;

    @FXML
    private Label dateLabel;

    @FXML
    private JFXDatePicker datepicker;

    @FXML
    private JFXButton button2;

    @FXML
    private ListView <String> nameListView;

    @FXML
    private ListView <String> quantityListView;

    @FXML
    private ListView <String> dateListView;
    @FXML
    private ListView<String> mobileListView;
    
    @FXML
    private Label msglabel;
    
    @FXML
    private JFXButton deletebuttun;
    
      

     // -----------------ACTIONS--------------------// 
          private Stage stage;
          private Scene scene;
          private Parent root;
          
          @FXML
    void Home(ActionEvent event) throws IOException {
Parent root = FXMLLoader.load(getClass().getResource("home.fxml"));
stage=(Stage)((Node)event.getSource()).getScene().getWindow();
scene=new Scene(root);
stage.setScene(scene);
stage.show();
    }
    
    
     @FXML
    void key(KeyEvent event) {
   msglabel.setText(" ");
    }
    
    
    
    
    
    
    /*
        @FXML
    void delete(ActionEvent event) {
       String name=nameTextFeild.getText();
       int indexn=obName.indexOf(name);
       obName.remove(indexn);
       obaddress.remove(indexn);
       obDate.remove(indexn);
       obmobile.remove(indexn);
       msglabel.setText(name+" was Deleted");
    }
    */
    
    
    
    
    /*
      @FXML
    void addbuttun(ActionEvent event) {
         
        
         if(nameTextFeild.getText().isEmpty() || mobileTextFeild.getText().isEmpty() ) //TextField FName 
             msglabel.setText("fill the fields");
        
         else{
      
        
           obName.add(nameTextFeild.getText());
           nameListView.setItems(obName);
           
           obmobile.add(mobileTextFeild.getText());
           mobileListView.setItems(obmobile);
            
            
          String s = compobox.getSelectionModel().getSelectedItem().toString();
          obaddress.add(s);
          quantityListView.setItems(obaddress);
           
          LocalDate date =datepicker.getValue();
          String s2=date.toString();
          obDate.add(s2);
          dateListView.setItems(obDate);
         
         }
         
         
         donor donor1=new donor();
         donor1.setDonor_name(nameTextFeild.getText());
         donor1.setDonor_mobile(mobileTextFeild.getText());
         donor1.setDonor_address(compobox.getValue());
         donor1.setDonation_date(datepicker.getValue().toString());
         
         
        Session session = HibernateUtil.getSessionFactory().openSession();
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(donor1);
        tx.commit();
        session.close();
            
         
    }
*/

    //-----------------------------END ACTIONS-------------------------//

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
               
         
          ObservableList<String> list = FXCollections.observableArrayList("Riyadh-11564","Makkah-24230","Madinah-20012","Jeddah-21577","Dammam-32241","Amlaj-48313","Unaizah-51911","Abha-61321");
          compobox.setItems(list);
         
          
        
         
         obName=FXCollections.observableArrayList();
         nameListView.setItems(obName);
         
         obmobile=FXCollections.observableArrayList();
          mobileListView.setItems(obmobile);
     
         obaddress=FXCollections.observableArrayList();
         quantityListView.setItems(obaddress);
       
         obDate=FXCollections.observableArrayList();
          dateListView.setItems(obDate);
          
          button2.setOnAction(e->{
              
              
               
         if(nameTextFeild.getText().isEmpty() || mobileTextFeild.getText().isEmpty() ) //TextField FName 
             msglabel.setText("fill the fields");
        
         else{
      
        
           obName.add(nameTextFeild.getText());
           nameListView.setItems(obName);
           
           obmobile.add(mobileTextFeild.getText());
           mobileListView.setItems(obmobile);
            
            
          String s = compobox.getSelectionModel().getSelectedItem().toString();
          obaddress.add(s);
          quantityListView.setItems(obaddress);
           
          LocalDate date =datepicker.getValue();
          String s2=date.toString();
          obDate.add(s2);
          dateListView.setItems(obDate);
         
          
          
         donor_pojo donor1=new donor_pojo();
         donor1.setDonor_name(nameTextFeild.getText());
         donor1.setDonor_address(compobox.getValue());
         donor1.setDonor_mobile(mobileTextFeild.getText());
         donor1.setDonation_date(datepicker.getValue().toString());
         
         
        Session session2 = HibernateUtil.getSessionFactory().openSession();
        session2 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx2 = session2.beginTransaction();
                 
        donor1.setCompany_id(company_id);
        tx2.commit();
        session2.close();
         
        
        
        
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(donor1);
        tx.commit();
        session.close();
         
         }
         
         

              
              
              
           });
          
          


    }    
    
}
