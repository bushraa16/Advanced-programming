/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advenced_programming_pro;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
public class Bag_sectionController implements Initializable {

    
        @FXML
    private JFXButton cartbutton;
    
    @FXML
    private VBox chosenbag;

    @FXML
    private VBox addressbox;

    @FXML
    private Label addressname;

    @FXML
    private Label addresscity;

    @FXML
    private Label addresscode;

    @FXML
    private ImageView bagimage;
    
        @FXML
    private ScrollPane scroll;

    @FXML
    private GridPane grid;
   
     @FXML
    private Button addButton;
     

     
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    
        @FXML
    void GoHome(ActionEvent event) throws IOException {
Parent root = FXMLLoader.load(getClass().getResource("home.fxml"));
stage=(Stage)((Node)event.getSource()).getScene().getWindow();
scene=new Scene(root);
stage.setScene(scene);
stage.show();
    }
    

    

    
      private bag bag;
      
    
    private List<bag> bags= new ArrayList<>();

    

    private Image image;
    private myListener myListener;
    
    
    
    
    private List<bag> getData(){   // نسوي ارري ونخزن داخلها اوبجكتس
        
        List<bag> bags = new ArrayList<>();
        bag bag; //just intilise object 
        
       
        bag=new bag();
        bag.setMaddressname("Mrs.Amal");
        bag.setMaddresscity("jeddah 12987-7318");
        bag.setMaddresscode("0566473524");
        bag.setImgSrc("bag1.jpeg");
        bag.setColor("F7C995");
        bags.add(bag);  // add to  List<bag> bags= new ArrayList<>();
        
        bag=new bag();
        bag.setMaddressname("Mrs.Hannan");
        bag.setMaddresscity("RIYADH 11564");
        bag.setMaddresscode("0566363524");
        bag.setImgSrc("bag22.jpeg");
        bag.setColor("D3967A");
        bags.add(bag);
        
        bag=new bag();
        bag.setMaddressname("Mrs.Sara");
        bag.setMaddresscity("NAJRAN 122-64");
        bag.setMaddresscode("0546473443");
        bag.setImgSrc("pexels-photo-45981.jpeg");
        bag.setColor("EAEAEA");
        bags.add(bag);
        
        bag=new bag();
        bag.setMaddressname("Mrs.Razan");
        bag.setMaddresscity("ABHA 176-94");
        bag.setMaddresscode("0533763524");
        bag.setImgSrc("bag3.jpeg");
        bag.setColor("E2E538");
        bags.add(bag);
        
        bag=new bag();
        bag.setMaddressname("Mrs.Shahad");
        bag.setMaddresscity("JEDDAH 165-04");
        bag.setMaddresscode("0333366372");
        bag.setImgSrc("bag5.jpeg");
        bag.setColor("B6B6B6");
        bags.add(bag);
        
        bag=new bag();
        bag.setMaddressname("Mrs.NAWAL");
        bag.setMaddresscity("MAKKAH 122-64");
        bag.setMaddresscode("0556473548");
        bag.setImgSrc("bag6.jpeg");
        bag.setColor("D9AFAF");
        bags.add(bag);
        
        
        
        
        
        
        /*

        SAUDI ARABIA
        jeddah 12987-7318
                
        
        */

        
        return bags;
        
        
    }
    
    
    
    
    
    
    
    
    
   
    
    
    // chosen bag card
    
    private void setChosenBag(bag bag) {   //استخدمناه تحت  , تعبي اللي فالكارد
       
        addressname.setText(bag.getMaddressname());
        addresscity.setText(bag.getMaddresscity());
        addresscode.setText(bag.getMaddresscode());
        image = new Image(getClass().getResourceAsStream(bag.getImgSrc())); 
        bagimage.setImage(image);
        chosenbag.setStyle("-fx-background-color: #"+bag.getColor()+";"+"-fx-background-radius: 30;"); //  يجيب اللون حق الكارد المختاره

    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     
         bags.addAll(getData());   //خزنا دداخل الاريي لست اري لست 
       
         
         
         if(bags.size() > 0){
             setChosenBag(bags.get(0));  // ??????????????????????????????????   هنا بس حطيت اول باق فقط 
             
             myListener=new myListener() {
                 @Override  // from the interface
                 public void onClickListener(bag bag) {                       ////؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟؟ ارجع اشوف الفيديو + افهم اللسنير 
                                                                              ///اذا انا سويت اكشن هنا فعل هذي الجزئيه 
                    setChosenBag(bag);  // نمرر هذي الاوبجكت في المربع اليسار
                 }

                 
             };
                 
                 
             
         }
         int column=0;
         int row=1;
         try {
            for(int i = 0 ; i<bags.size(); i++){  // هنا نضيف اف السايز لايساوي الصفر 
         
             FXMLLoader fxmlloader= new FXMLLoader(); // 
             fxmlloader.setLocation(getClass().getResource("item.fxml"));            //اجيب السين اللي في  fxml item   /*فيه شرح فاليوتيوب*/
             AnchorPane anchorpane= fxmlloader.load();              //سوينا انككور وحطينا داخله السين اللي في الايتم 
             
           //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
           
            ItemController itemcontroller = fxmlloader.getController();
            itemcontroller.setData(bags.get(i),myListener); // ميثور في الايتم كنترولير 2 
            
            if(column == 3){     //اذا العامود صار ثلاثه ارجع من العامود 0 وزود الصف واحد 
                column=0;
                row++;
            }
            
           
             //set grid width
            grid.add(anchorpane,column++,row); //(child,colomun,row) // ابحث قوقل , هنا ضاف فالقرد الايتم 
            grid.setMinWidth(Region.USE_COMPUTED_SIZE);
            grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
            grid.setMaxWidth(Region.USE_PREF_SIZE);
            GridPane.setMargin(anchorpane, new Insets(10, 10, 10, 10));
            
            //set grid hight
            
            grid.setMinHeight(Region.USE_COMPUTED_SIZE);
            grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
            grid.setMaxHeight(Region.USE_PREF_SIZE);
            
            
         }
            } catch (IOException ex) {
                 Logger.getLogger(Bag_sectionController.class.getName()).log(Level.SEVERE, null, ex);
                 
                 
             }

    }    
    
}
