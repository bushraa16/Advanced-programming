/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advenced_programming_pro;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="donor_table_db")
public class donor_pojo implements java.io.Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "donor_id")    
private int donor_id;
    
    @Column(name = "donor_name")
private String donor_name;
    
    @Column(name = "donor_address")
private String donor_address;
    
    @Column(name = "donor_mobile")
private String donor_mobile;
    
    @Column(name = "donation_time")
private String donation_date;
    
    @Column(name = "company_id")
    private int company_id;
    
    


    public donor_pojo() {
    }

    public donor_pojo(int donor_id, String donor_name, String donor_address, String donor_mobile, String donation_date) {
        this.donor_id = donor_id;
        this.donor_name = donor_name;
        this.donor_address = donor_address;
        this.donor_mobile = donor_mobile;
        this.donation_date = donation_date;
     
    }

    public int getCompany_id() {
        return company_id;
    }

    public void setCompany_id(int company_id) {
        this.company_id = company_id;
    }



    public int getDonor_id() {
        return donor_id;
    }

    public void setDonor_id(int donor_id) {
        this.donor_id = donor_id;
    }

    public String getDonor_name() {
        return donor_name;
    }

    public void setDonor_name(String donor_name) {
        this.donor_name = donor_name;
    }

    public String getDonor_address() {
        return donor_address;
    }

    public void setDonor_address(String donor_address) {
        this.donor_address = donor_address;
    }

    public String getDonor_mobile() {
        return donor_mobile;
    }

    public void setDonor_mobile(String donor_mobile) {
        this.donor_mobile = donor_mobile;
    }

    public String getDonation_date() {
        return donation_date;
    }

    public void setDonation_date(String donation_date) {
        this.donation_date = donation_date;
    }


    
}
