/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advenced_programming_pro;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author xxsha
 */
public class ItemController implements Initializable {

            @FXML
    private Label iaddressname;

    @FXML
    private Label iaddresscity;

    @FXML
    private Label iaddresscode;

    @FXML
    private ImageView img;
    
    
    
    
    @FXML
    private void click(MouseEvent mouseEvent){
        myListener.onClickListener(bag);
        
    }
    

    
   
    
    private bag bag;
    
 private myListener myListener;
    
    
    
    
    
    public void setData(bag bag, myListener myListener){
        this.bag=bag;
        this.myListener = myListener;
       iaddressname.setText(bag.getMaddressname());
        iaddresscity.setText(bag.getMaddresscity());
       iaddresscode.setText(bag.getMaddresscode());
        Image image = new Image(getClass().getResourceAsStream(bag.getImgSrc()));
        img.setImage(image);
        
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
