/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advenced_programming_pro;

import static advenced_programming_pro.Sign_upController.company_id;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import org.hibernate.Query;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class LoginController implements Initializable {
    
   public static  String name=null;
  public static    String emaill=null;
  public static    String passwordd=null;
  public static int id=0;

   private static final String regex = "^(.+)@(.+)$";
  @FXML
    private MediaView mediaView;
  
      @FXML
    private JFXTextField emailfeild;

    @FXML
    private JFXPasswordField passwordfeild;
  
      @FXML
    private Label msg;
          @FXML
    private JFXButton delete;
  
  
  @FXML
    private JFXButton loginbotton;


    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    void GOTOTHEHOME(ActionEvent event) throws IOException {
               root = FXMLLoader.load(getClass().getResource("home.fxml"));
                stage=(Stage)((Node)event.getSource()).getScene().getWindow();
                scene=new Scene(root);
                stage.setScene(scene);
                stage.show();

    }
        @FXML
    void GOTOTHESIGNUP(ActionEvent event) throws IOException {
                Parent root = FXMLLoader.load(getClass().getResource("sign_up.fxml"));
stage=(Stage)((Node)event.getSource()).getScene().getWindow();
scene=new Scene(root);
stage.setScene(scene);
stage.show();

    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
             Media media = new Media("file:///C:/Users/xxsha/Desktop/vedio.mp4");
        MediaPlayer player = new MediaPlayer(media);
        mediaView.setMediaPlayer(player);
        player.setCycleCount(MediaPlayer.INDEFINITE);
        player.setVolume(0);
        player.play();

        
        
        
        
        
        
        
     
        
        
        
        
        

        loginbotton.setOnAction(e->{ 
            
            
            
          /*  
          Session  session = HibernateUtil.getSessionFactory().openSession();
          Transaction tx2 = null;
          tx2 = session.beginTransaction();
         String hqlDel = "SELECT firstName, lastName, salary FROM old_employee";
                 org.hibernate.Query queryDel = session.createQuery(hqlDel);
                 int resultD = queryDel.executeUpdate();
                 System.out.println("Rows affected: " + resultD);
                 tx2.commit();
                 session.close();
            
            */
          
          
  
            
            
            
            
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(emailfeild.getText());
        boolean validate =matcher.matches();
        
               if(emailfeild.getText().isEmpty()||passwordfeild.getText().isEmpty()) //TextField FName 
               msg.setText("Please Complete the fields");
               
               
               else{
                   
                     if(!validate) 
                         msg.setText("invalid Email"); 
                     else{
                             
                         if(passwordfeild.getText().length() <8)
                         msg.setText("The length must be higher than 8 digits"); 
                         else{
                             
                             msg.setText("");
                             String email = emailfeild.getText();
                             String password = passwordfeild.getText(); 
                             int id;
                            
                             
                             Session session = HibernateUtil.getSessionFactory().openSession();
                             session = HibernateUtil.getSessionFactory().openSession();
                             Transaction tx = session.beginTransaction();
                             List<commpany_pojo> sList = null;
                             String queryStr = "from commpany_pojo";
                             Query query=  session.createQuery(queryStr);
                             sList=query.list();
                             session.close();
                               
                               for(commpany_pojo s: sList){
                               
                                if(s.getCompany_email().equals(email)&&s.getCompany_paasword().equals(password))
                                {   
                                    
                             id=s.getCompany_id();
                           //   name=s.getCompany_name();
                            //  emaill=s.getCompany_email();
                            //  passwordd=s.getCompany_paasword();
                            
                             
                                                try {
                                                    
                              
                                                     root = FXMLLoader.load(getClass().getResource("home.fxml"));
                                                     stage=(Stage)((Node)e.getSource()).getScene().getWindow();
                                                     scene=new Scene(root);
                                                     stage.setScene(scene);
                                                     stage.show();
                           
                                 
                               
                               
                                } catch (IOException ex) {
                                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                                
                                                
                                                
                                                
                                                
                                }
                                
                                else{
                                        
                                         msg.setText("no user found"); 
                                        
                                        }
                                
                                
                                
                                     }
           
                         
                         
                         
                         
                         
                         }

                             }

                   
               }

            
         });
       
        
        
        
        
    }    
    
}
