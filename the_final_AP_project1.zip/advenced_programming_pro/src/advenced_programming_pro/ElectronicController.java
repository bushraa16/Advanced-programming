/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advenced_programming_pro;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
public class ElectronicController implements Initializable {

    
    
    @FXML
    private VBox chosenbag;

    @FXML
    private VBox addressbox;

    @FXML
    private Label addressname;

    @FXML
    private Label addresscity;

    @FXML
    private Label addresscode;

    @FXML
    private ImageView shoesimage;
    
        @FXML
    private ScrollPane scroll;

    @FXML
    private GridPane grid;
    
        private Stage stage;
    private Scene scene;
    private Parent root;
    
        @FXML
    void gohome(ActionEvent event) throws IOException {
Parent root = FXMLLoader.load(getClass().getResource("home.fxml"));
stage=(Stage)((Node)event.getSource()).getScene().getWindow();
scene=new Scene(root);
stage.setScene(scene);
stage.show();
    }
    
    
    private List<bag> elec= new ArrayList<>();
    private Image image;
    private myListener myListener;
    
    private List<bag> getData(){
        
        List<bag> ele = new ArrayList<>();
        bag elec; //just intilise object 
        
       
        elec=new bag();
        elec.setMaddressname("Ms.Hana");
        elec.setMaddresscity("Makkah 12933-4518");
        elec.setMaddresscode("0566473872");
        elec.setImgSrc("elc.jpeg");
        elec.setColor("F7C995");
        ele.add(elec);  // add to up private List<bag> bags= new ArrayList<>();
        
        elec=new bag();
        elec.setMaddressname("Ms.Maha");
        elec.setMaddresscity("RIYADH 11564");
        elec.setMaddresscode("0566473524");
        elec.setImgSrc("elc2.jpeg");
        elec.setColor("D3967A");
        ele.add(elec);
        
        elec=new bag();
        elec.setMaddressname("Ms.Sara");
        elec.setMaddresscity("NAJRAN 98706-0944");
        elec.setMaddresscode("0566473542");
        elec.setImgSrc("elc3.jpeg");
        elec.setColor("EAEAEA");
        ele.add(elec);
        
         elec=new bag();
        elec.setMaddressname("Ms.Amanda");
        elec.setMaddresscity("Buraydah 123296-7071");
        elec.setMaddresscode("0566473652");
        elec.setImgSrc("elc4.jpeg");
        elec.setColor("EAEAEA");
        ele.add(elec);
        
         elec=new bag();
        elec.setMaddressname("Ms.Aya ");
        elec.setMaddresscity("Hofuf 14567-77");
        elec.setMaddresscode("0366478372");
        elec.setImgSrc("elc5.jpeg");
        elec.setColor("EAEAEA");
        ele.add(elec);
       

        
        return ele;
        
        
    }
    
    
    // chosen bag card
    
    private void setChosenShoes(bag elec){   //استخدمناه تحت 
        addressname.setText(elec.getMaddressname());
        addresscity.setText(elec.getMaddresscity());
        addresscode.setText(elec.getMaddresscode());
        image = new Image(getClass().getResourceAsStream(elec.getImgSrc())); 
        shoesimage.setImage(image);
        chosenbag.setStyle("-fx-background-color: #"+elec.getColor()+";"+"-fx-background-radius: 30;"); //  يجيب اللون حق الكارد المختاره
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
         elec.addAll(getData());
         if(elec.size() > 0){
             setChosenShoes(elec.get(0));
             myListener=new myListener() {
                 @Override
                 public void onClickListener(bag elec) {
                    setChosenShoes(elec);
                 }
             };
                 
                 
             
         }
         int column=0;
         int row=1;
         try {
            for(int i = 0 ; i<elec.size(); i++){
         
             FXMLLoader fxmlloader= new FXMLLoader(); // لازم افهمه و سوينا امبورت اسأل خصوصي
             fxmlloader.setLocation(getClass().getResource("item.fxml"));            //موجود فالمين 
             AnchorPane anchorpane= fxmlloader.load();
           
            ItemController itemcontroller = fxmlloader.getController();
            itemcontroller.setData(elec.get(i),myListener); // ميثور في الايتم كنترولير
            
            if(column == 3){
                column=0;
                row++;
            }
            
           
             //set grid width
            grid.add(anchorpane,column++,row); //(child,colomun,row) // ابحث قوقل
            grid.setMinWidth(Region.USE_COMPUTED_SIZE);
            grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
            grid.setMaxWidth(Region.USE_PREF_SIZE);
            GridPane.setMargin(anchorpane, new Insets(10, 10, 10, 10));
            
            //set grid hight
            
            grid.setMinHeight(Region.USE_COMPUTED_SIZE);
            grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
            grid.setMaxHeight(Region.USE_PREF_SIZE);
            
            
         }
            } catch (IOException ex) {
                 Logger.getLogger(ElectronicController.class.getName()).log(Level.SEVERE, null, ex);
                 
                 
             }
    }    
    
}
