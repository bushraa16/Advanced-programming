/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advenced_programming_pro;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
public class Clothes_sectionController implements Initializable {

   
 
    
    @FXML
    private VBox chosenbag;

    @FXML
    private VBox addressbox;

    @FXML
    private Label addressname;

    @FXML
    private Label addresscity;

    @FXML
    private Label addresscode;

    @FXML
    private ImageView bagimage;
    
        @FXML
    private ScrollPane scroll;

    @FXML
    private GridPane grid;
    
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    
        @FXML
    void gohome(ActionEvent event) throws IOException {
Parent root = FXMLLoader.load(getClass().getResource("home.fxml"));
stage=(Stage)((Node)event.getSource()).getScene().getWindow();
scene=new Scene(root);
stage.setScene(scene);
stage.show();
    }
    
    
    
    private List< bag>  clothesy= new ArrayList<>();
    private Image image;
    private myListener myListener;
    
    private List<bag> getData(){
        
        List< bag> clothesy1= new ArrayList<>();
        bag clothesy; //just intilise object 
        
       
      clothesy=new  bag();
        clothesy.setMaddressname("Mrs.Afnan");
       clothesy.setMaddresscity("Makkah 12907-8008");
        clothesy.setMaddresscode("0877254776");
         clothesy.setImgSrc("clothees.jpg");
       clothesy.setColor("CFCDD0");
    clothesy1.add( clothesy);  // add to up private List<bag> bags= new ArrayList<>();
        
        clothesy=new  bag();
   clothesy.setMaddressname("Mrs.Hana");
       clothesy.setMaddresscity("RIYADH 2243");
      clothesy.setMaddresscode("0564554744");
      clothesy.setImgSrc("clothes.jpg");
    clothesy.setColor("787878");
       clothesy1.add( clothesy);
        
       clothesy=new  bag();
      clothesy.setMaddressname("Mrs.Lama");
      clothesy.setMaddresscity("jeddah 122");
      clothesy.setMaddresscode("0566333333");
      clothesy.setImgSrc("clothses.jpg");
 clothesy.setColor("6874A3");
      clothesy1.add(clothesy);
           
     clothesy=new bag();
     clothesy.setMaddressname("Mrs.Sara");
      clothesy.setMaddresscity("Aljbeal 122-64");
     clothesy.setMaddresscode("0566748352");
     clothesy.setImgSrc("babay.jpg");
       clothesy.setColor("F08080");
    clothesy1.add(clothesy);
             
   clothesy=new bag();
 clothesy.setMaddressname("Mrs.Alaa");
clothesy.setMaddresscity("  jeddah 2234");
clothesy.setMaddresscode("0566473975");
clothesy.setImgSrc("v.jpg");
  clothesy.setColor("D3967A");
        clothesy1.add(clothesy);
             
       clothesy=new bag();
   clothesy.setMaddressname("Mrs.Seba");
 clothesy.setMaddresscity("  Makkah 1022");
clothesy.setMaddresscode("0566473864");
clothesy.setImgSrc("vvvvvvv.jpg");
clothesy.setColor("862D2D");
    clothesy1 .add(clothesy);
        
        return clothesy1;
        
        
    }
    private void setChosenBag(bag clothesy){   
        addressname.setText(clothesy.getMaddressname());
        addresscity.setText(clothesy.getMaddresscity());
        addresscode.setText(clothesy.getMaddresscode());
        image = new Image(getClass().getResourceAsStream(clothesy.getImgSrc())); 
        bagimage.setImage(image);
        chosenbag.setStyle("-fx-background-color: #"+clothesy.getColor()+";"+"-fx-background-radius: 30;");
        
        
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
           
        
       clothesy.addAll(getData());
         if(clothesy.size() > 0){
             setChosenBag(clothesy.get(0));
             myListener=new myListener() {
                 @Override
                 public void onClickListener(bag clothesy) {
                    setChosenBag(clothesy);
                 }
             };    
         }
         int column=0;
         int row=1;
         try {
            for(int i = 0 ; i<clothesy.size(); i++){
         
             FXMLLoader fxmlloader= new FXMLLoader();
             fxmlloader.setLocation(getClass().getResource("item.fxml"));        
             AnchorPane anchorpane= fxmlloader.load();
           
            ItemController itemcontroller = fxmlloader.getController();
            itemcontroller.setData(clothesy.get(i),myListener);
            
            if(column == 3){
                column=0;
                row++;
            }
             //set grid width
            grid.add(anchorpane,column++,row); //(child,colomun,row) 
            grid.setMinWidth(Region.USE_COMPUTED_SIZE);
            grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
            grid.setMaxWidth(Region.USE_PREF_SIZE);
            GridPane.setMargin(anchorpane, new Insets(10, 10, 10, 10));
            
            //set grid hight
            
            grid.setMinHeight(Region.USE_COMPUTED_SIZE);
            grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
            grid.setMaxHeight(Region.USE_PREF_SIZE);
            
            
         }
            } catch (IOException ex) {
                 Logger.getLogger(Clothes_sectionController.class.getName()).log(Level.SEVERE, null, ex);
                 
                 
             }
    }    
    
}
