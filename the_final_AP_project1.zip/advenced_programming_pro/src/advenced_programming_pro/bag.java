/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advenced_programming_pro;


public class bag {
    
    private String Maddressname;
    private String Maddresscity;
    private String Maddresscode;
    private String imgSrc;
    private String color;

    public String getMaddressname() {
        return Maddressname;
    }

    public void setMaddressname(String Maddressname) {
        this.Maddressname = Maddressname;
    }

    public String getMaddresscity() {
        return Maddresscity;
    }

    public void setMaddresscity(String Maddresscity) {
        this.Maddresscity = Maddresscity;
    }

    public String getMaddresscode() {
        return Maddresscode;
    }

    public void setMaddresscode(String Maddresscode) {
        this.Maddresscode = Maddresscode;
    }

    public String getImgSrc() {
        return imgSrc;
    }

    public void setImgSrc(String imgSrc) {
        this.imgSrc = imgSrc;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    @Override
    public String toString() {
        return "bag{" + "Maddressname=" + Maddressname + ", Maddresscity=" + Maddresscity + ", Maddresscode=" + Maddresscode + ", imgSrc=" + imgSrc + ", color=" + color + '}';
    }
    
}
