/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advenced_programming_pro;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;




@Entity
@Table(name="company_table_db")
public class commpany_pojo implements java.io.Serializable  {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "company_id")     
private int company_id; 
    
    @Column(name = "company_name")
private String company_name;
    
    @Column(name = "company_email")
private String company_email;
    
    @Column(name = "company_password")
private String company_paasword;

    public commpany_pojo() {
         this.company_id = company_id;
    }

    public commpany_pojo(int company_id, String company_name, String company_email, String company_paasword) {
        this.company_id = company_id;
        this.company_name = company_name;
        this.company_email = company_email;
        this.company_paasword = company_paasword;
    }

    public int getCompany_id() {
        return company_id;
    }

    public void setCompany_id(int company_id) {
        this.company_id = company_id;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getCompany_email() {
        return company_email;
    }

    public void setCompany_email(String company_email) {
        this.company_email = company_email;
    }

    public String getCompany_paasword() {
        return company_paasword;
    }

    public void setCompany_paasword(String company_paasword) {
        this.company_paasword = company_paasword;
    }



    
}
